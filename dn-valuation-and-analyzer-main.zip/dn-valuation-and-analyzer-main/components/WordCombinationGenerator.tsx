
import React, { useState } from 'react';
import { getWordCombinations } from '../services/geminiService';
import type { WordCombination } from '../types';
import { Spinner } from './common/Spinner';
import { Icon } from './common/Icon';

export const WordCombinationGenerator: React.FC = () => {
    const [primaryWords, setPrimaryWords] = useState('block, data, meta');
    const [secondaryWords, setSecondaryWords] = useState('chain, flow, engine, hub');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [results, setResults] = useState<WordCombination[]>([]);

    const handleGenerate = async () => {
        if (!primaryWords || !secondaryWords) {
            setError('Please enter words in both fields.');
            return;
        }
        setIsLoading(true);
setError(null);
        setResults([]);
        try {
            const data = await getWordCombinations(primaryWords, secondaryWords);
            setResults(data);
        } catch (e) {
            setError('Failed to generate combinations. Please check your API key and try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const ResultCard: React.FC<{ item: WordCombination }> = ({ item }) => {
        const availabilityColor = item.availability === 'Likely Available' ? 'text-green-400' : 
                                  item.availability === 'Premium' ? 'text-yellow-400' : 'text-red-400';
        return (
            <div className="bg-slate-800 p-4 rounded-lg border border-slate-700 flex flex-col justify-between">
                <div>
                    <h4 className="text-lg font-bold text-white">{item.domainName}</h4>
                    <p className={`text-sm font-semibold ${availabilityColor}`}>{item.availability}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                        {item.tlds.map(tld => (
                             <span key={tld} className="bg-sky-500/20 text-sky-300 text-xs font-semibold px-2 py-0.5 rounded-full">.{tld}</span>
                        ))}
                    </div>
                    <div className="mt-3">
                        <p className="text-xs text-slate-400">Brandability</p>
                        <div className="flex items-center gap-2">
                             <div className="w-full bg-slate-700 rounded-full h-1.5">
                                <div className="bg-sky-500 h-1.5 rounded-full" style={{ width: `${item.brandabilityScore}%` }}></div>
                            </div>
                            <span className="text-sm font-semibold">{item.brandabilityScore}</span>
                        </div>
                    </div>
                    <p className="text-xs text-slate-400 mt-2">Industry: <span className="font-semibold text-slate-300">{item.industry}</span></p>
                </div>
                <button className="w-full mt-4 bg-transparent border border-sky-500 text-sky-400 text-xs font-semibold py-1.5 px-3 rounded-md hover:bg-sky-500 hover:text-white transition">
                    Send to Valuation
                </button>
            </div>
        )
    };

    return (
        <div className="mt-8 bg-slate-800/50 p-6 rounded-lg border border-slate-700/50">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Primary Words (Theme)</label>
                    <input
                        type="text"
                        value={primaryWords}
                        onChange={(e) => setPrimaryWords(e.target.value)}
                        className="w-full rounded-md border-0 bg-slate-700 px-3.5 py-2 text-white shadow-sm ring-1 ring-inset ring-slate-600 focus:ring-2 focus:ring-inset focus:ring-sky-500"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Secondary Words (Context)</label>
                    <input
                        type="text"
                        value={secondaryWords}
                        onChange={(e) => setSecondaryWords(e.target.value)}
                        className="w-full rounded-md border-0 bg-slate-700 px-3.5 py-2 text-white shadow-sm ring-1 ring-inset ring-slate-600 focus:ring-2 focus:ring-inset focus:ring-sky-500"
                    />
                </div>
            </div>
            <button
                onClick={handleGenerate}
                disabled={isLoading}
                className="w-full md:w-auto mx-auto flex-none rounded-md bg-sky-600 px-6 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-700 disabled:bg-slate-600 flex items-center justify-center gap-2"
            >
                {isLoading ? <Spinner className="w-5 h-5" /> : 'Generate Combinations'}
            </button>
            {error && <p className="mt-2 text-sm text-red-400 text-center">{error}</p>}

            <div className="mt-8">
                 <h3 className="text-xl font-bold text-white mb-4">Generated Domain Ideas</h3>
                 {isLoading ? (
                    <div className="flex justify-center items-center h-64"><Spinner className="w-10 h-10"/></div>
                 ) : results.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {results.map(item => <ResultCard key={item.domainName} item={item} />)}
                    </div>
                 ) : (
                    <div className="text-center py-12 text-slate-500">
                        <Icon name="lightbulb" className="w-12 h-12 mx-auto" />
                        <p className="mt-2">Your generated domain ideas will appear here.</p>
                    </div>
                 )}
            </div>
        </div>
    );
};
